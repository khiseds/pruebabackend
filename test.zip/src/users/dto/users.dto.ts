export class UsersDto {
    nombreEmpresa: string;
    idEmpresa: string;
    email: string;
    password: string;
    admin: string;
    Puedeconectaraweb: string
}