export class passwordResetsDto {
    claveCliente:string;
    tokenCliente:string;
    fechaExpiracion:string;
    usado:string;
}